$dir = [System.Environment]::CurrentDirectory
Add-MpPreference -ExclusionPath "$($dir)"